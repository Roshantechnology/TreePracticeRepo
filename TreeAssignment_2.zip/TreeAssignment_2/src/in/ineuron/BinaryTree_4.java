package in.ineuron;

import java.util.LinkedList;
import java.util.Queue;
class Node1 {
	int data;
	Node1 left, right, nextRight;
	Node1(int item)
	{
		data = item;
		left = right = nextRight = null;
	}
}
public class BinaryTree_4 {
	Node1 root;
	void connect(Node1 p)
	{
		Queue<Node1> q = new LinkedList<>();
		q.add(root);

		Node1 temp = null;
		while (!q.isEmpty()) {
			int n = q.size();
			for (int i = 0; i < n; i++) {
				Node1 prev = temp;
				temp = q.poll();
				if (i > 0)
					prev.nextRight = temp;

				if (temp.left != null)
					q.add(temp.left);

				if (temp.right != null)
					q.add(temp.right);
			}
			temp.nextRight = null;
		}
	}
	public static void main(String args[])
	{
		BinaryTree_4 tree = new BinaryTree_4();
		tree.root = new Node1(1);
		tree.root.left = new Node1(2);
		tree.root.right = new Node1(3);
		tree.root.left.left = new Node1(4);
		tree.root.left.right = new Node1(5);
		tree.root.right.left = new Node1(6);
		tree.root.right.right = new Node1(7);
		tree.connect(tree.root);

		int a = tree.root.nextRight != null ? tree.root.nextRight.data : -1;
		System.out.println( tree.root.data + "-----> " + a);
		int b = tree.root.left.nextRight != null ? tree.root.left.nextRight.data : -1;
		System.out.println(tree.root.left.data + "-----> "+ b);
		int c = tree.root.right.nextRight != null ? tree.root.right.nextRight.data : -1;
		System.out.println(tree.root.right.data + "-----> "+ c);
		int d = tree.root.left.left.nextRight != null ? tree.root.left.left.nextRight.data : -1;
		System.out.println(tree.root.left.left.data + "-----> " + d);
		int e = tree.root.left.right.nextRight != null ? tree.root.left.right.nextRight.data : -1;
		System.out.println( tree.root.left.right.data + "-----> " + e);
		int f = tree.root.right.left.nextRight != null ? tree.root.right.left.nextRight.data : -1;
		System.out.println(tree.root.right.left.data + "-----> " + f);
		int g = tree.root.right.right.nextRight != null ? tree.root.right.right.nextRight.data : -1;
		System.out.println(tree.root.right.right.data + "-----> " + g);
	}
}
