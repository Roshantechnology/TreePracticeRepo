package in.ineuron;
class Node 
{
    int data;
    Node left, right;
   
    public Node(int data) 
    {
        this.data = data;
        left = right = null;
    }
}
public class DoublyLinkedList_3 
{
    Node root;
    Node head;
    static Node prev = null;
    void BinaryTree2DoubleLinkedList(Node root) 
    {
        if (root == null)
            return;
        BinaryTree2DoubleLinkedList(root.left);
        if (prev == null) 
            head = root;
        else
        {
            root.left = prev;
            prev.right = root;
        }
        prev = root;
        BinaryTree2DoubleLinkedList(root.right);
    }
    void printList(Node node)
    {
        while (node != null) 
        {
            System.out.print(node.data + " ");
            node = node.right;
        }
    }
    public static void main(String[] args) 
    {
        DoublyLinkedList_3 tree = new DoublyLinkedList_3();
        tree.root = new Node(10);
        tree.root.left = new Node(5);
        tree.root.right = new Node(20);
        tree.root.right.right = new Node(35);
        tree.root.right.left = new Node(30);
        tree.BinaryTree2DoubleLinkedList(tree.root);
        tree.printList(tree.head);
   
    }
}